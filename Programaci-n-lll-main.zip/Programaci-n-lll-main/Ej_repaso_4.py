lista=[5,78,2,45]
def ordenado_mayor_menor(lista):
    lista.sort()
    return lista

ordenado_mayor_menor(lista)
print(lista)